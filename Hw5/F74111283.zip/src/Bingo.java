public class Bingo {
    public int check(String[][] mat){

        return 0;
    }
}
